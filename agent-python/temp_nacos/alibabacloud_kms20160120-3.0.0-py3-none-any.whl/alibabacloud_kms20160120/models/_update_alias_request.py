# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class UpdateAliasRequest(DaraModel):
    def __init__(
        self,
        alias_name: str = None,
        key_id: str = None,
    ):
        # The alias that you want to bind.
        # 
        # The value must be 1 to 255 characters in length and must include the alias/ prefix.
        # 
        # This parameter is required.
        self.alias_name = alias_name
        # The ID of the CMK. The ID must be globally unique.
        # 
        # This parameter is required.
        self.key_id = key_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.alias_name is not None:
            result['AliasName'] = self.alias_name

        if self.key_id is not None:
            result['KeyId'] = self.key_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AliasName') is not None:
            self.alias_name = m.get('AliasName')

        if m.get('KeyId') is not None:
            self.key_id = m.get('KeyId')

        return self

